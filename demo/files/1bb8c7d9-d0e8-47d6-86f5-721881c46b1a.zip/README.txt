Workload & Backlog (report workload-backlog, version 2)
Filters: Look-ahead (days): 30
Data as of: Oct 16, 2026, 7:47 AM (America/New_York)
Run: 142

One CSV per card, in report order (UTF-8 with BOM, opens in Excel).