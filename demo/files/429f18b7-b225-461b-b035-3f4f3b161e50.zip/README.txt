Capital Projects Summary (report capital-projects-summary, version 3)
Filters: none
Data as of: Oct 16, 2026, 7:47 AM (America/New_York)
Run: 98

One CSV per card, in report order (UTF-8 with BOM, opens in Excel).