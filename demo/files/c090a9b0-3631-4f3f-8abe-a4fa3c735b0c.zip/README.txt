Monthly Activity Trend (report monthly-activity-trend, version 1)
Filters: Months: 12
Data as of: Oct 16, 2026, 7:47 AM (America/New_York)
Run: 118

One CSV per card, in report order (UTF-8 with BOM, opens in Excel).