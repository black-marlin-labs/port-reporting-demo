Workload & Backlog (report workload-backlog, version 2)
Filters: Layer: Facilities, Look-ahead (days): 30
Data as of: Oct 16, 2026, 7:43 AM (America/New_York)
Run: 89

One CSV per card, in report order (UTF-8 with BOM, opens in Excel).