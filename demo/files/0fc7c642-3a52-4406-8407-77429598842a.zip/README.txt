Capital Projects Summary (report capital-projects-summary, version 3)
Filters: Program: Airport Project
Data as of: Oct 16, 2026, 7:44 AM (America/New_York)
Run: 90

One CSV per card, in report order (UTF-8 with BOM, opens in Excel).